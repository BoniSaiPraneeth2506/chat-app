const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BdduVAH7.js","assets/index-lI6VavBn.js","assets/index-CB21NpHJ.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-lI6VavBn.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-BdduVAH7.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
