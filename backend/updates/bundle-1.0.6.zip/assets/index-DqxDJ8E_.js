const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BZmGSeJS.js","assets/index-DRIraDmO.js","assets/index-Dpm-oPv8.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-DRIraDmO.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-BZmGSeJS.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
