const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CQ8IxVwG.js","assets/index-CluBE3mE.js","assets/index-ejDkwqEP.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-CluBE3mE.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-CQ8IxVwG.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
