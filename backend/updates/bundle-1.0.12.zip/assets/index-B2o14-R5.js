const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dukm4lD4.js","assets/index-DHu1y0fC.js","assets/index-DmRGrgU7.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-DHu1y0fC.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-Dukm4lD4.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
