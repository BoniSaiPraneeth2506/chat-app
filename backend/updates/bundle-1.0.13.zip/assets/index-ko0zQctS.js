const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-C67cF9UZ.js","assets/index-eA7cAUah.js","assets/index-CtibDACL.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-eA7cAUah.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-C67cF9UZ.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
