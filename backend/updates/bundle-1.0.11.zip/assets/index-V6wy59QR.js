const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BHfad9wK.js","assets/index-DV6YpEU2.js","assets/index-DmRGrgU7.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-DV6YpEU2.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-BHfad9wK.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
