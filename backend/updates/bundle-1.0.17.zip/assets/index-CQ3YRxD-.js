const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-BtN7rlyH.js","assets/index-BIa_uK3X.js","assets/index-bAArckoO.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-BIa_uK3X.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-BtN7rlyH.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
