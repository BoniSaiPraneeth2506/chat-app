const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-r-bF2N9J.js","assets/index-DvgC27hX.js","assets/index-DlEl6ynl.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-DvgC27hX.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-r-bF2N9J.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
