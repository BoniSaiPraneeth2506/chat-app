const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-CNY4O_YN.js","assets/index-CFUtTUQv.js","assets/index-OH-wELx5.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-CFUtTUQv.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-CNY4O_YN.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
