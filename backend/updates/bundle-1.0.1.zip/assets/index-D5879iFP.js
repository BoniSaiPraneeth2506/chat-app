const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-TOXrf9Sw.js","assets/index-BcKoRb-n.js","assets/index-DcKrwpzc.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-BcKoRb-n.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-TOXrf9Sw.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
