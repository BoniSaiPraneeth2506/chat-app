const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-UH4hFbrO.js","assets/index-CnOEiJmi.js","assets/index-CB21NpHJ.css"])))=>i.map(i=>d[i]);
import{r as e,a as t,f as i}from"./index-CnOEiJmi.js";const a=e("Geolocation",{web:()=>t(()=>import("./web-UH4hFbrO.js"),__vite__mapDeps([0,1,2])).then(o=>new o.GeolocationWeb)});i();export{a as Geolocation};
